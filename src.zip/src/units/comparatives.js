// src/units/comparatives.js
// Unidad completa: comparativos, superlativos y adverbios comparativos

export const comparativesUnit = {
  id: 'comparatives',
  grammarTitle: 'Comparatives & Superlatives',
  title: 'Comparing people, things and actions',
  description: 'Learn to compare using adjectives and adverbs with "than" and superlatives with "the".',

  // ─────────────────────────────────────────────────────────────────────────
  // THEORY
  // ─────────────────────────────────────────────────────────────────────────
  
theoryBlock: {
  comparative: {
    title: 'Comparative Adjectives: old/older, expensive/more expensive',
    content: [
      {
        type: 'text',
        text: 'We use <strong>comparatives</strong> to say that one thing has more or less of a quality than another. The form depends on the <strong>number of syllables</strong> in the adjective.',
      },
      {
        type: 'table',
        headers: ['Adjective', 'Comparative', 'Example'],
        rows: [
          ['old',         'older',           'Athens is <em>older</em> than Rome.'],
          ['cheap',       'cheaper',         'Is it <em>cheaper</em> to go by car?'],
          ['big',         'bigger',          'Helen wants a <em>bigger</em> car.'],
          ['easy',        'easier',          'It\'s <em>easier</em> to take a taxi.'],
          ['expensive',   'more expensive',  'Gold is <em>more expensive</em> than silver.'],
          ['interesting', 'more interesting','I want something <em>more interesting</em>.'],
          ['good / well', 'better',          'Today is <em>better</em> than yesterday.'],
          ['bad',         'worse',           'I feel <em>worse</em> today.'],
          ['far',         'further',         'The station is <em>further</em> than I thought.'],
        ],
      },
      {
        type: 'rule',
        text: '<strong>Short adjectives (1 syllable)</strong>: add <strong>-er</strong> → old → older, cheap → cheaper, nice → nicer',
      },
      {
        type: 'rule',
        text: '<strong>CVC adjectives</strong> (consonant-vowel-consonant): double the final consonant → big → bi<strong>gg</strong>er, hot → ho<strong>tt</strong>er, thin → thi<strong>nn</strong>er',
      },
      {
        type: 'rule',
        text: '<strong>Adjectives ending in -y</strong>: change -y → <strong>-ier</strong> → easy → easier, heavy → heavier, early → earlier',
      },
      {
        type: 'rule',
        text: '<strong>Long adjectives (2+ syllables)</strong>: use <strong>more</strong> before the adjective → more careful, more expensive, more interesting',
      },
      {
        type: 'rule',
        warn: true,
        text: '~~more old~~ → <strong>older</strong> | ~~more easy~~ → <strong>easier</strong> (short adjectives never use more)',
      },
      {
        type: 'rule',
        warn: true,
        text: '~~more better~~ → <strong>better</strong> | ~~more worse~~ → <strong>worse</strong> (irregular forms never use more)',
      },
      {
        type: 'example',
        en: 'Rome is old, but Athens is <strong>older</strong>.',
        es: 'Roma es antigua, pero Atenas es más antigua.',
      },
      {
        type: 'example',
        en: 'I don\'t like my job. I want to do something <strong>more interesting</strong>.',
        es: 'No me gusta mi trabajo. Quiero hacer algo más interesante.',
      },
      {
        type: 'example',
        en: '\'Do you feel better today?\' \'No, I feel <strong>worse</strong>.\'',
        es: '\'¿Te encuentras mejor hoy?\' \'No, me encuentro peor.\'',
      },
      {
        type: 'teacher',
        text: 'Use <strong>one method only</strong> — either -er OR more, never both. ~~more older~~ and ~~more bigger~~ are always wrong. Next: how to use comparatives with <strong>than</strong>.',
      },
    ],
  },

  comparativeThan: {
    title: 'older than … / more expensive than …',
    content: [
      {
        type: 'text',
        text: 'After a comparative, we use <strong>than</strong> to introduce the second element. After <em>than</em>, use object pronouns (<strong>me, him, her, us, them</strong>) in informal English.',
      },
      {
        type: 'table',
        headers: ['Informal (more common)', 'Formal (also correct)'],
        rows: [
          ['I can run faster than <strong>him</strong>.', 'I can run faster than <strong>he can</strong>.'],
          ['You are a better singer than <strong>me</strong>.', 'You are a better singer than <strong>I am</strong>.'],
          ['I got up earlier than <strong>her</strong>.', 'I got up earlier than <strong>she did</strong>.'],
        ],
      },
      {
        type: 'example',
        en: 'Athens is <strong>older than</strong> Rome.',
        es: 'Atenas es más antigua que Roma.',
      },
      {
        type: 'example',
        en: 'Are oranges <strong>more expensive than</strong> bananas?',
        es: '¿Son las naranjas más caras que los plátanos?',
      },
      {
        type: 'example',
        en: 'It\'s <strong>easier</strong> to take a taxi <strong>than</strong> to take the bus.',
        es: 'Es más fácil tomar un taxi que tomar el autobús.',
      },
      {
        type: 'rule',
        text: 'Use <strong>a bit</strong> for small differences and <strong>much</strong> for big differences, always before the comparative → <strong>a bit older</strong>, <strong>much more expensive</strong>',
      },
      {
        type: 'rule',
        warn: true,
        text: '~~very older~~ → <strong>much older</strong> (never use <em>very</em> with comparatives — use <em>much</em>)',
      },
      {
        type: 'example',
        en: 'Sue is <strong>a bit older</strong> than Joe — she\'s 25 and he\'s 24.',
        es: 'Sue es un poco mayor que Joe: ella tiene 25 y él 24.',
      },
      {
        type: 'example',
        en: 'The hotel was <strong>much more expensive</strong> than I expected.',
        es: 'El hotel era mucho más caro de lo que esperaba.',
      },
      {
        type: 'tip',
        emoji: '💡',
        text: 'After <strong>than</strong>, use object pronouns in spoken English:<br/>✔ taller than <strong>me / him / her / us / them</strong><br/>✔ or a full clause: taller than <strong>he is</strong> / taller than <strong>she does</strong>',
      },
      {
        type: 'teacher',
        text: 'Remember: comparative + <strong>than</strong>, not ~~than more~~. Use <strong>much</strong> (not ~~very~~) to intensify. Next: when something is the best of all, not just better than one → <strong>superlatives</strong>.',
      },
    ],
  },

  superlative: {
    title: 'the oldest / the most expensive',
    content: [
      {
        type: 'text',
        text: 'Superlatives say something is <strong>the most / the least</strong> of a group. Always use <strong>the</strong> before a superlative. The formation rules are parallel to comparatives.',
      },
      {
        type: 'table',
        headers: ['Adjective', 'Comparative', 'Superlative'],
        rows: [
          ['old',         'older than',            'the <strong>oldest</strong>'],
          ['cheap',       'cheaper than',          'the <strong>cheapest</strong>'],
          ['big',         'bigger than',           'the <strong>biggest</strong>'],
          ['easy',        'easier than',           'the <strong>easiest</strong>'],
          ['heavy',       'heavier than',          'the <strong>heaviest</strong>'],
          ['expensive',   'more expensive than',   'the <strong>most expensive</strong>'],
          ['interesting', 'more interesting than',  'the <strong>most interesting</strong>'],
          ['good',        'better than',           'the <strong>best</strong>'],
          ['bad',         'worse than',            'the <strong>worst</strong>'],
          ['far',         'further than',          'the <strong>furthest</strong>'],
        ],
      },
      {
        type: 'rule',
        text: 'Irregular forms to memorise: <strong>good → better → the best</strong> | <strong>bad → worse → the worst</strong> | <strong>far → further → the furthest</strong>',
      },
      {
        type: 'rule',
        warn: true,
        text: '~~the most old~~ → <strong>the oldest</strong> | ~~the most big~~ → <strong>the biggest</strong> (short adjectives never use most)',
      },
      {
        type: 'rule',
        warn: true,
        text: '~~oldest building in town~~ → <strong>the oldest</strong> building in town (<em>the</em> is always required)',
      },
      {
        type: 'example',
        en: 'The church is very old. It\'s <strong>the oldest</strong> building in the town.',
        es: 'La iglesia es muy antigua. Es el edificio más antiguo de la ciudad.',
      },
      {
        type: 'example',
        en: 'Mount Everest is <strong>the highest</strong> mountain in the world.',
        es: 'El Everest es la montaña más alta del mundo.',
      },
      {
        type: 'example',
        en: 'It\'s <strong>the worst</strong> film I\'ve <strong>ever</strong> seen.',
        es: 'Es la peor película que he visto en mi vida.',
      },
      {
        type: 'tip',
        emoji: '📌',
        text: 'Pattern with place: the oldest building <strong>in</strong> the town | the best player <strong>in</strong> the team<br/>Pattern with experience: the worst film I\'ve <strong>ever</strong> seen | the best meal I\'ve <strong>ever</strong> eaten',
      },
      {
        type: 'teacher',
        text: 'The superlative always needs <strong>the</strong>. ~~Most expensive hotel~~ is always wrong — say <strong>the most expensive hotel</strong>. Key difference: <strong>older than</strong> (two things) vs <strong>the oldest</strong> (one vs all).',
      },
    ],
  },
},
  /*theoryBlock: {
    comparative: {
      title: 'Comparative Adjectives + THAN',
      content: [
        {
          type: 'text',
          text: 'We use comparatives to say that one thing is <strong>more/less</strong> than another. Always follow the comparative with <strong>than</strong>.',
        },
        {
          type: 'table',
          headers: ['Adjective', 'Comparative', 'Example'],
          rows: [
            ['tall',       'taller <strong>than</strong>',      'She is <em>taller than</em> her brother.'],
            ['fast',       'faster <strong>than</strong>',      'A cheetah is <em>faster than</em> a horse.'],
            ['big',        'bigger <strong>than</strong>',      'An elephant is <em>bigger than</em> a dog.'],
            ['happy',      'happier <strong>than</strong>',     'He is <em>happier than</em> yesterday.'],
            ['expensive',  'more expensive <strong>than</strong>', 'Gold is <em>more expensive than</em> silver.'],
            ['difficult',  'more difficult <strong>than</strong>', 'Maths is <em>more difficult than</em> art.'],
          ],
        },
        {
          type: 'rule',
          text: '<strong>Short adjectives (1 syllable)</strong>: add <strong>-er</strong> → tall → taller, fast → faster, old → older',
        },
        {
          type: 'rule',
          text: '<strong>Adjectives ending in -y</strong>: change y → i + er → happy → happier, easy → easier, funny → funnier',
        },
        {
          type: 'rule',
          text: '<strong>CVC adjectives</strong> (consonant-vowel-consonant): double the final consonant → big → bigger, hot → hotter, thin → thinner',
        },
        {
          type: 'rule',
          text: '<strong>Long adjectives (2+ syllables)</strong>: add <strong>more</strong> before → more interesting, more beautiful, more expensive',
        },
        {
          type: 'teacher',
          text: 'Never say ~~more taller~~ or ~~more faster~~! Use <strong>one method only</strong>: either -er OR more, never both.',
        },
        {
          type: 'example',
          en: 'My dog is <strong>bigger than</strong> your cat.',
          es: 'Mi perro es más grande que tu gato.',
        },
        {
          type: 'example',
          en: 'This film is <strong>more interesting than</strong> the book.',
          es: 'Esta película es más interesante que el libro.',
        },
      ],
    },

    superlative: {
      title: 'Superlative Adjectives',
      content: [
        {
          type: 'text',
          text: 'Superlatives say something is <strong>the most / the least</strong> of a group. Always use <strong>the</strong> before a superlative.',
        },
        {
          type: 'table',
          headers: ['Adjective', 'Comparative', 'Superlative'],
          rows: [
            ['tall',      'taller than',      'the <strong>tallest</strong>'],
            ['fast',      'faster than',      'the <strong>fastest</strong>'],
            ['big',       'bigger than',      'the <strong>biggest</strong>'],
            ['happy',     'happier than',     'the <strong>happiest</strong>'],
            ['expensive', 'more expensive than', 'the <strong>most expensive</strong>'],
            ['good',      'better than',      'the <strong>best</strong>'],
            ['bad',       'worse than',       'the <strong>worst</strong>'],
            ['far',       'further than',     'the <strong>furthest</strong>'],
          ],
        },
        {
          type: 'rule',
          text: 'Irregular forms to memorise: <strong>good → better → the best</strong> | <strong>bad → worse → the worst</strong> | <strong>far → further → the furthest</strong>',
        },
        {
          type: 'example',
          en: 'Mount Everest is <strong>the highest</strong> mountain in the world.',
          es: 'El Everest es la montaña más alta del mundo.',
        },
        {
          type: 'example',
          en: 'This is <strong>the most beautiful</strong> place I have ever seen.',
          es: 'Este es el lugar más bonito que he visto nunca.',
        },
      ],
    },

    adverbs: {
      title: 'Comparative Adverbs',
      content: [
        {
          type: 'text',
          text: 'Adverbs describe <strong>how</strong> an action happens. Comparative adverbs follow the same rules as adjectives but modify <strong>verbs</strong>, not nouns.',
        },
        {
          type: 'table',
          headers: ['Adverb', 'Comparative', 'Example'],
          rows: [
            ['fast',       'faster <strong>than</strong>',       'She runs <em>faster than</em> her sister.'],
            ['hard',       'harder <strong>than</strong>',       'He works <em>harder than</em> anyone else.'],
            ['high',       'higher <strong>than</strong>',       'The eagle flies <em>higher than</em> the hawk.'],
            ['early',      'earlier <strong>than</strong>',      'I arrived <em>earlier than</em> expected.'],
            ['carefully',  'more carefully <strong>than</strong>', 'Drive <em>more carefully than</em> before.'],
            ['quickly',    'more quickly <strong>than</strong>',  'She finished <em>more quickly than</em> him.'],
            ['well',       'better <strong>than</strong>',        'He sings <em>better than</em> me.'],
            ['badly',      'worse <strong>than</strong>',         'I played <em>worse than</em> yesterday.'],
          ],
        },
        {
          type: 'rule',
          text: '<strong>Short adverbs</strong> (fast, hard, late, high): add <strong>-er</strong> → faster, harder, later, higher',
        },
        {
          type: 'rule',
          text: '<strong>Adverbs ending in -ly</strong>: use <strong>more</strong> → more carefully, more quietly, more quickly',
        },
        {
          type: 'tip',
          emoji: '⚡',
          text: 'Key difference: <br/>• <strong>She is faster than me.</strong> → adjective (describes her) <br/>• <strong>She runs faster than me.</strong> → adverb (describes how she runs)',
        },
        {
          type: 'example',
          en: 'Tom speaks English <strong>more fluently than</strong> his classmates.',
          es: 'Tom habla inglés con más fluidez que sus compañeros.',
        },
        {
          type: 'example',
          en: 'My cat wakes up <strong>earlier than</strong> the alarm.',
          es: 'Mi gato se despierta más temprano que el despertador.',
        },
      ],
    },

    asAs: {
      title: 'As … as (Equality)',
      content: [
        {
          type: 'text',
          text: 'Use <strong>as + adjective/adverb + as</strong> to say two things are equal. Use <strong>not as … as</strong> for inequality.',
        },
        {
          type: 'example',
          en: 'Your bag is <strong>as heavy as</strong> mine.',
          es: 'Tu mochila pesa igual que la mía.',
        },
        {
          type: 'example',
          en: 'She is <strong>not as tall as</strong> her brother.',
          es: 'Ella no es tan alta como su hermano.',
        },
        {
          type: 'tip',
          emoji: '💡',
          text: 'Pattern: <strong>as [adj] as</strong> → She is <em>as smart as</em> Einstein. | <strong>not as [adj] as</strong> → He is <em>not as fast as</em> Usain Bolt.',
        },
      ],
    },
  },*/

  // ─────────────────────────────────────────────────────────────────────────
  // QUIZ — 6 exercise types
  // ─────────────────────────────────────────────────────────────────────────
  theoryQuiz: [
    // 1. Fill — comparative with THAN
    {
      id: 'comp-f1',
      type: 'fill',
      q: 'An elephant is ______ a mouse. (big)',
      ans: 'bigger than',
      explanation: '"Big" is CVC → double the g → bigger. Always add "than" after a comparative.',
    },
    // 2. Fill — superlative
    {
      id: 'comp-f2',
      type: 'fill',
      q: 'She is ______ student in the class. (intelligent)',
      ans: 'the most intelligent',
      explanation: 'Long adjective → "the most + adjective".',
    },
    // 3. Fill — adverb comparative
    {
      id: 'comp-f3',
      type: 'fill',
      q: 'He drives ______ his father. (carefully)',
      ans: 'more carefully than',
      explanation: 'Adverb ending in -ly → "more carefully than".',
    },
    // 4. Fill — as...as
    {
      id: 'comp-f4',
      type: 'fill',
      q: 'My sister is ______ clever ______ me. (equal)',
      ans: 'as, as',
      explanation: 'Equality: as + adjective + as.',
    },
    // 5. Choice — irregular
    {
      id: 'comp-c1',
      type: 'choice',
      q: 'Which sentence is correct?',
      options: [
        'Today I feel more good than yesterday.',
        'Today I feel better than yesterday.',
        'Today I feel gooder than yesterday.',
        'Today I feel more better than yesterday.',
      ],
      ans: 'Today I feel better than yesterday.',
      explanation: '"Good" is irregular: good → better → the best.',
    },
    // 6. Choice — adverb vs adjective
    {
      id: 'comp-c2',
      type: 'choice',
      q: 'Choose the correct sentence:',
      options: [
        'She sings more beautiful than her sister.',
        'She sings more beautifully than her sister.',
        'She sings beautifullier than her sister.',
        'She sings most beautifully than her sister.',
      ],
      ans: 'She sings more beautifully than her sister.',
      explanation: '"Sings" is a verb → use an adverb: more beautifully (not the adjective "beautiful").',
    },
    // 7. Choice — superlative
    {
      id: 'comp-c3',
      type: 'choice',
      q: 'The Amazon is ______ river in the world.',
      options: ['longer', 'the longest', 'the most long', 'most longest'],
      ans: 'the longest',
      explanation: 'Superlatives: short adjective → the + -est. Always use "the".',
    },
    // 8. Error — missing THAN
    {
      id: 'comp-e1',
      type: 'error',
      q: 'Maths is more difficult Science.',
      ans: 'Maths is more difficult than Science.',
      explanation: 'Comparatives MUST be followed by "than" when comparing two things.',
    },
    // 9. Error — double comparative
    {
      id: 'comp-e2',
      type: 'error',
      q: 'She is more taller than her brother.',
      ans: 'She is taller than her brother.',
      explanation: '"Tall" is a short adjective → just add -er. Never use "more" AND -er together.',
    },
    // 10. Order — adverb sentence
    {
      id: 'comp-o1',
      type: 'order',
      words: ['runs', 'faster', 'than', 'Maria', 'her', 'sister'],
      ans: 'Maria runs faster than her sister',
      explanation: 'Subject + verb + comparative adverb + than + object.',
    },
    // 11. Translate ES→EN — comparative
    {
      id: 'comp-t1',
      type: 'translate',
      q: 'El verano es más caluroso que el invierno.',
      hint: 'Use "hot" → comparative',
      ans: 'Summer is hotter than winter.|Summer is more hot than winter.',
      explanation: '"Hot" is CVC → double the t: hotter.',
    },
    // 12. Translate ES→EN — superlative
    {
      id: 'comp-t2',
      type: 'translate',
      q: 'Es el libro más aburrido que he leído.',
      hint: 'Use "boring" → superlative',
      ans: 'It is the most boring book I have ever read.|It is the most boring book I have read.',
      explanation: 'Long adjective → the most boring.',
    },
    // 13. Translate ES→EN — adverb
    {
      id: 'comp-t3',
      type: 'translate',
      q: 'Hablas inglés mejor que yo.',
      hint: 'well → comparative adverb (irregular)',
      ans: 'You speak English better than me.|You speak English better than I do.',
      explanation: '"Well" is irregular: well → better (not "more well").',
    },
    // 14. Translate ES→EN — as...as
    {
      id: 'comp-t4',
      type: 'translate',
      q: 'Mi gato no es tan rápido como el tuyo.',
      hint: 'not as ... as',
      ans: 'My cat is not as fast as yours.',
      explanation: 'Inequality: not as + adjective + as.',
    },
    // 15. MatchPairs — comparative form
    {
      id: 'comp-m1',
      type: 'matchpairs',
      q: 'Match the adjective to its comparative form:',
      leftLabel: 'Adjective',
      rightLabel: 'Comparative',
      pairs: [
        { left: 'good',      right: 'better than'          },
        { left: 'bad',       right: 'worse than'           },
        { left: 'far',       right: 'further than'         },
        { left: 'beautiful', right: 'more beautiful than'  },
        { left: 'thin',      right: 'thinner than'         },
      ],
    },
    // 16. MatchPairs — Spanish to English adverbs
    {
      id: 'comp-m2',
      type: 'matchpairs',
      q: 'Match the Spanish sentence to its English translation:',
      leftLabel: '🇪🇸 Español',
      rightLabel: '🇬🇧 English',
      pairs: [
        { left: 'Corre más rápido que yo.',     right: 'He runs faster than me.'           },
        { left: 'Trabaja más duro que nadie.',  right: 'She works harder than anyone.'     },
        { left: 'Llegué más temprano que tú.',  right: 'I arrived earlier than you.'       },
        { left: 'Habla más despacio ahora.',    right: 'He speaks more slowly now.'        },
      ],
    },
  ],

  // ─────────────────────────────────────────────────────────────────────────
  // VOCABULARY
  // ─────────────────────────────────────────────────────────────────────────
  vocabulary: [
    { id: 'v1',  word: 'taller',        span: 'más alto' },
    { id: 'v2',  word: 'shorter',       span: 'más bajo' },
    { id: 'v3',  word: 'bigger',        span: 'más grande' },
    { id: 'v4',  word: 'smaller',       span: 'más pequeño' },
    { id: 'v5',  word: 'faster',        span: 'más rápido' },
    { id: 'v6',  word: 'slower',        span: 'más lento' },
    { id: 'v7',  word: 'better',        span: 'mejor' },
    { id: 'v8',  word: 'worse',         span: 'peor' },
    { id: 'v9',  word: 'more expensive', span: 'más caro' },
    { id: 'v10', word: 'cheaper',       span: 'más barato' },
    { id: 'v11', word: 'the tallest',   span: 'el más alto' },
    { id: 'v12', word: 'the best',      span: 'el mejor' },
    { id: 'v13', word: 'the worst',     span: 'el peor' },
    { id: 'v14', word: 'the most beautiful', span: 'el más bonito' },
    { id: 'v15', word: 'as tall as',    span: 'tan alto como' },
    { id: 'v16', word: 'not as fast as', span: 'no tan rápido como' },
  ],

  // ─────────────────────────────────────────────────────────────────────────
  // LISTENING
  // ─────────────────────────────────────────────────────────────────────────
  listening: {
    text: "My sister is taller than me, but I am faster than her. She is the most patient person in our family. I think maths is more difficult than English, but my teacher says I work harder than most students. Our dog runs more quickly than our cat, but the cat is definitely the laziest animal in the house.",
    options: ['taller', 'faster', 'the most patient', 'more difficult', 'harder', 'more quickly', 'the laziest', 'the biggest'],
    correctItems: ['taller', 'faster', 'the most patient', 'more difficult', 'harder', 'more quickly', 'the laziest'],
  },
};

// Reading block — añadido por arquitectura fix
export const comparativesReadingPatch = {
  reading: {
    title: 'Faster, Higher, Stronger',
    source: 'English Studio · Level A2',
    passage: `The Olympic motto is "Citius, Altius, Fortius" — in English, "Faster, Higher, Stronger." These three words are all comparative adjectives, and they perfectly describe what the Olympic Games are about: athletes trying to perform better than they did before, and better than their competitors.

In the 100-metre sprint, the winner is simply the runner who is faster than all the others. But in sports like gymnastics or diving, judges decide who is more graceful, more controlled, and more precise. The best athlete is not always the strongest — sometimes, the most flexible or the most creative wins.

Modern athletes are generally bigger, faster, and stronger than athletes from 100 years ago. A sprinter today is significantly faster than the world record holder from 1924. Swimmers today are more than two minutes quicker in the 1500-metre freestyle than they were in the early Olympic Games. Training methods are more scientific, nutrition is more carefully planned, and equipment is more advanced than ever before.

However, some experts argue that natural talent is still more important than technology. The greatest athletes are not just faster or stronger — they are also more mentally resilient, more disciplined, and more passionate about their sport than average competitors.`,
    questions: [
      {
        id: 'r1',
        type: 'mc',
        q: 'What does the Olympic motto "Citius, Altius, Fortius" mean in English?',
        options: ['Faster, Higher, Stronger', 'Better, Smarter, Quicker', 'Harder, Higher, Further', 'Faster, Stronger, Braver'],
        ans: 'Faster, Higher, Stronger',
        explanation: 'The passage states directly: "in English, Faster, Higher, Stronger".',
      },
      {
        id: 'r2',
        type: 'mc',
        q: 'In which sports do judges decide the winner?',
        options: ['100-metre sprint and swimming', 'Gymnastics and diving', 'Swimming and cycling', 'All Olympic sports'],
        ans: 'Gymnastics and diving',
        explanation: 'The text says "in sports like gymnastics or diving, judges decide who is more graceful…"',
      },
      {
        id: 'r3',
        type: 'mc',
        q: 'According to the text, why are modern athletes generally better than athletes from 100 years ago?',
        options: [
          'They are naturally more talented',
          'The Olympic Games are more popular',
          'Training, nutrition and equipment are more advanced',
          'They train for more hours each day',
        ],
        ans: 'Training, nutrition and equipment are more advanced',
        explanation: 'Paragraph 3 lists: "Training methods are more scientific, nutrition is more carefully planned, and equipment is more advanced."',
      },
      {
        id: 'r4',
        type: 'sa',
        q: 'Find TWO comparative adjectives used to describe what makes the greatest athletes special (beyond physical ability).',
        ans: 'more mentally resilient|more disciplined|more passionate',
        explanation: 'The final paragraph mentions: more mentally resilient, more disciplined, more passionate.',
      },
      {
        id: 'r5',
        type: 'mc',
        q: 'Which sentence uses a comparative adverb correctly?',
        options: [
          'Swimmers today swim more quick than in 1924.',
          'Swimmers today swim more quickly than in 1924.',
          'Swimmers today swim quicklier than in 1924.',
          'Swimmers today swim most quickly than in 1924.',
        ],
        ans: 'Swimmers today swim more quickly than in 1924.',
        explanation: '"Quickly" ends in -ly, so the comparative is "more quickly". Never add -er to adverbs ending in -ly.',
      },
    ],
  },
};
